<?php
// +----------------------------------------------------------------------
// | 子枫后台管理系统(TpFast系列)[基于ThinkPHP5.1开发]
// +----------------------------------------------------------------------
// | Copyright (c)  http://v1.fast.zf.90ckm.com/
// | 子枫后台管理系统提供免费使用,可使用此框架进行二次开发
// +----------------------------------------------------------------------
// | Author: 子枫 <287851074@qq.com>
// +----------------------------------------------------------------------
// | github:https://github.com/wmc1125/zfAdmin_tpfast
// | 码云:  https://gitee.com/wmc1125/zfAdmin_tpfast
// | Mc技术论坛: http://bbs.wangmingchang.com/forum.php?mod=forumdisplay&fid=77
// +----------------------------------------------------------------------

namespace app\demo\controller;
use think\Db;
use \Firebase\JWT\JWT;
class JwtTest extends Base
{
    public function index()
    {
        echo "index";
    }
    
    public function test(){
    	$key = "example_key";
		$token = array(
		    "iss" => "http://example.org",
		    "aud" => "http://example.com",
		    "iat" => 1356999524,
		    "nbf" => 1357000000
		);
		$jwt = JWT::encode($token, $key);
		$decoded = JWT::decode($jwt, $key, array('HS256'));
		print_r($decoded);

		$decoded_array = (array) $decoded;

		JWT::$leeway = 60; // $leeway in seconds
		$decoded = JWT::decode($jwt, $key, array('HS256'));
		        
    }
    public function test2()
	{
		$key = '111@22'; //key
		$time = time(); //当前时间

		//公用信息
		$token = [
        	'iss' => 'http://www.helloweba.net', //签发者 可选
            'iat' => $time, //签发时间
            'data' => [ //自定义信息，不要定义敏感信息
             	'userid' => 1,
            ]
        ];

		$access_token = $token;
		$access_token['scopes'] = 'role_access'; //token标识，请求接口的token
		$access_token['exp'] = $time+7200; //access_token过期时间,这里设置2个小时

		$refresh_token = $token;
		$refresh_token['scopes'] = 'role_refresh'; //token标识，刷新access_token
		$refresh_token['exp'] = $time+(86400 * 30); //access_token过期时间,这里设置30天

		$jsonList = [
			'access_token'=>JWT::encode($access_token,$key),
			'refresh_token'=>JWT::encode($refresh_token,$key),
			'token_type'=>'bearer' //token_type：表示令牌类型，该值大小写不敏感，这里用bearer
		];
        Header("HTTP/1.1 201 Created");
		$json =  json_encode($jsonList); //返回给客户端token信息
		dd($jsonList);
	}
	// 验证签名
	public function verification()
	{
		$key = '111@22'; //key要和签发的时候一样
		$jwt = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOlwvXC93d3cuaGVsbG93ZWJhLm5ldCIsImlhdCI6MTU4ODgyMDcwMiwiZGF0YSI6eyJ1c2VyaWQiOjF9LCJzY29wZXMiOiJyb2xlX2FjY2VzcyIsImV4cCI6MTU4ODgyMDcxMn0.rK3D_eJs14TgyZ55sqMbCoDwbOwEAN8fId-Ud6ySF7g"; //签发的Token
		try {
	       		JWT::$leeway = 60;//当前时间减去60，把时间留点余地
	       		$decoded = JWT::decode($jwt, $key, ['HS256']); //HS256方式，这里要和签发的时候对应
	       		$arr = (array)$decoded;
	       		print_r($arr);
	    	} catch(\Firebase\JWT\SignatureInvalidException $e) {  //签名不正确
	    		echo $e->getMessage();
	    	}catch(\Firebase\JWT\BeforeValidException $e) {  // 签名在某个时间点之后才能用
	    		echo $e->getMessage();
	    	}catch(\Firebase\JWT\ExpiredException $e) {  // token过期
	    		echo $e->getMessage();
	    		//过期
	   	}catch(Exception $e) {  //其他错误
	    		echo $e->getMessage();
	    	}
	    //Firebase定义了多个 throw new，我们可以捕获多个catch来定义问题，catch加入自己的业务，比如token过期可以用当前Token刷新一个新Token
	}
    


  
   


}

