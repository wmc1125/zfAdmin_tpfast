<?php
// +----------------------------------------------------------------------
// | 子枫后台管理系统(TpFast系列)[基于ThinkPHP5.1开发]
// +----------------------------------------------------------------------
// | Copyright (c)  http://v1.fast.zf.90ckm.com/
// | 子枫后台管理系统提供免费使用,可使用此框架进行二次开发
// +----------------------------------------------------------------------
// | Author: 子枫 <287851074@qq.com>
// +----------------------------------------------------------------------
// | github:https://github.com/wmc1125/zfAdmin_tpfast
// | 码云:  https://gitee.com/wmc1125/zfAdmin_tpfast
// | Mc技术论坛: http://bbs.wangmingchang.com/forum.php?mod=forumdisplay&fid=77
// +----------------------------------------------------------------------

namespace app\demo\controller;
use think\Db;
class Weiyuanchuang extends Base
{
    public function index()
    {
        echo "index";
    }
  
    public function test2(){
        $spinner = new Ikeepstudying();
        $text = '
       不能自已 
        ';
        echo '<h2>Dict</h2><pre>'; print_r($spinner->synonyms); echo '</pre>';
        echo $text;
        echo '<h2>New Content (after every refresh, it may be differnt words)</h2>'.$spinner->replace($text);
       
    }



  
   


}
/**
 * Ikeepstudying : PHP伪原创类
 * Author: ikeepstudying
 * Create at: 2016-03-11 10:49
 */
class Ikeepstudying
{
    private $replaced = array();
    public $synonyms = array();
    
    //construct
    function __construct()
    {
        $this->synonyms = require(dirname(__FILE__).'/data_ciku.php');

                        
            
    }
    
    //replace
    function replace($text)
    {
        foreach($this->synonyms as $key => $val) {
            if(preg_match("/".$key."/", $text) && !in_array($key, $this->replaced)) {
                $text = str_replace($key, (is_array($val)?$val[array_rand($val)]:$val), $text);
                array_push($this->replaced, $val);
            }
        }
        
        return $text;
    }
}
