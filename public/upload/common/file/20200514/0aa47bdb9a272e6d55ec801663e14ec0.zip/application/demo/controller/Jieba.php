<?php
// +----------------------------------------------------------------------
// | 子枫后台管理系统(TpFast系列)[基于ThinkPHP5.1开发]
// +----------------------------------------------------------------------
// | Copyright (c)  http://v1.fast.zf.90ckm.com/
// | 子枫后台管理系统提供免费使用,可使用此框架进行二次开发
// +----------------------------------------------------------------------
// | Author: 子枫 <287851074@qq.com>
// +----------------------------------------------------------------------
// | github:https://github.com/wmc1125/zfAdmin_tpfast
// | 码云:  https://gitee.com/wmc1125/zfAdmin_tpfast
// | Mc技术论坛: http://bbs.wangmingchang.com/forum.php?mod=forumdisplay&fid=77
// +----------------------------------------------------------------------

namespace app\demo\controller;
use think\Db;
use Fukuball\Jieba\Jieba;
use Fukuball\Jieba\Finalseg;

use Fukuball\Jieba\JiebaAnalyse;
class Jieba extends Base
{
    public function index()
    {
        echo "index";
    }
  
    public function test(){
        ini_set('memory_limit', '1024M');
        Jieba::init();
        Finalseg::init();

        $seg_list = Jieba::cut("怜香惜玉也得要看对象啊！");
        var_dump($seg_list);

        $seg_list = Jieba::cut("我来到北京清华大学", true);
        var_dump($seg_list); #全模式

        $seg_list = Jieba::cut("我来到北京清华大学", false);
        var_dump($seg_list); #默認精確模式

        $seg_list = Jieba::cut("他来到了网易杭研大厦");
        var_dump($seg_list);

        $seg_list = Jieba::cutForSearch("小明硕士毕业于中国科学院计算所，后在日本京都大学深造"); #搜索引擎模式
        var_dump($seg_list);

       
    }
    public function test2(){
       ini_set('memory_limit', '600M');

        
        Jieba::init(array('mode'=>'test','dict'=>'small'));
        Finalseg::init();
        JiebaAnalyse::init();

$top_k = 10;
$content = file_get_contents("/path/to/your/dict/lyric.txt", "r");

$tags = JiebaAnalyse::extractTags($content, $top_k);

var_dump($tags);

JiebaAnalyse::setStopWords('/path/to/your/dict/stop_words.txt');

$tags = JiebaAnalyse::extractTags($content, $top_k);

var_dump($tags); 
    }



  
   


}