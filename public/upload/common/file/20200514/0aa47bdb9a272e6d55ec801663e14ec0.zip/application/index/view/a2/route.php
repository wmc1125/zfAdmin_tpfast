<?php

Route::get('', 'index/a2.index/index');
Route::get('index', 'index/a2.index/index');
Route::get('list', 'index/a2.cate/listt');
Route::get('detail', 'index/a2.cate/detail');