<?php
	$config = [
		'name'=>'展示1',
		'theme_name'=>'def',
		'version'=>'v1.0.0',
		'pic'=>'http://v1.fast.zf.90ckm.com/public/upload/file/20191009/69d39aca7605312da5a6d47833e2fac8.png',
		'ctime'=>'2019-7-24',
		'summary'=>'ssssssssss',
		'author'=>'eric'
	];
