<?php
// +----------------------------------------------------------------------
// | 子枫后台管理系统(TpFast系列)[基于ThinkPHP5.1开发]
// +----------------------------------------------------------------------
// | Copyright (c)  http://v1.fast.zf.90ckm.com/
// | 子枫后台管理系统提供免费使用,可使用此框架进行二次开发
// +----------------------------------------------------------------------
// | Author: 子枫 <287851074@qq.com>
// +----------------------------------------------------------------------
// | github:https://github.com/wmc1125/zfAdmin_tpfast
// | 码云:  https://gitee.com/wmc1125/zfAdmin_tpfast
// | Mc技术论坛: http://bbs.wangmingchang.com/forum.php?mod=forumdisplay&fid=77
// +----------------------------------------------------------------------

namespace app\admin\controller;
use think\facade\Request;
use think\Db;
use EasyWeChat\Factory;

class Wechat extends Admin
{
    public function __construct (){
        parent::__construct();
    }

    
    public function index(){
        // $this->test();die;
        echo '公众号<br>';
        echo "<a target='_blank' href='/admin/wechat/gzh_setting.html'>基本设置</a><br>";
        echo "<a target='_blank' href='/admin/wechat/gzh_automsg.html'>自动回复列表</a><br>";
        echo "<a target='_blank' href='/admin/wechat/gzh_user.html'>用户</a><br>";
        echo "<a target='_blank' href='/admin/wechat/gzh_media.html'>媒体</a><br>";
        echo "<a target='_blank' href='/admin/wechat/gzh_qrcode.html'>带参数二维码</a><br>";
        echo "<a target='_blank' href='/admin/wechat/gzh_menu.html'>菜单</a><br>";
        
        //基本设置

        //菜单

        //回复

        //素材×




        // echo '-------------';
        // echo '小程序<br>';
        // echo '-------------';
        // echo '开放平台<br>';
        // echo '-------------';
        // echo '支付<br>';
        // echo '-------------';
    }
    public function gzh_setting(){

        admin_role_check($this->z_role_list,$this->mca,1);
        if(request()->isPost()){
            $data = request()->post();
            $res = Db::name('wx_config')->where(['uid'=>session('admin')['id'],'id'=>$data['id']])->update($data);
            return ZFRetMsg($res,'修改成功','修改失败');
        }
        $data = Db::name('wx_config')->where(['uid'=>session('admin')['id']])->find();
        if(!$data){
            $is = Db::name('wx_config')->insert(['uid'=>session('admin')['id']]);
            $data = Db::name('wx_config')->where(['uid'=>session('admin')['id']])->find();
        }
        $this->assign('data',$data);
        return view();
    }
    public function gzh_menu(){
        $this->conf(session('admin')['id']);

        $t = request()->get('t','');
        if($t=='init_json'){
            // $data = '{"menu": {"button": [{"name": "菜单名称","type": "view"}]}}';
            $data = $this->app->menu->list();
            // dd(json_encode(json_decode($data)));
            if(isset($data['errcode']) && $data['errcode']=='46003'){
                return jserror('');
            }
            return jssuccess($data);
        }elseif($t=='save_json'){
            $data = request()->post();
            $buttons = object_to_array(json_decode($data['data'])->menu)['button'];
            $r = $this->app->menu->create($buttons);
            if($r['errcode']==0){
                Db::name('wx_config')->where(['uid'=>session('admin')['id']])->update(['menu'=>$data['data']]);

                return jssuccess('发布成功');
            }else{
                return jserror($r['errmsg']);
            }
        }elseif($t=='del_menu'){
            $r = $this->app->menu->delete(); // 全部
            if($r['errcode']==0){
                return jssuccess('删除成功');
            }else{
                return jserror($r['msg']);
            }
        }


        $data = [];

        $this->assign('data',$data);
        return view();
    }

    public function gzh_automsg($cid=''){
        admin_role_check($this->z_role_list,$this->mca);
        if($cid!='' && $cid!='{cid'){
            $where[] = ['cid','=',$cid];
        }
        $where[] = ['status','<>',9];
        $where[] = ['cuid','=',session('admin')['id']];
        $list = Db::name('wx_gzh_automsg')->where($where)->order("sort desc,id desc")->paginate(10);
        $page = $list->render();
        $this->assign("page",$page);
        $this->assign('list',$list);
        $this->assign('cid',$cid);
        return view();
    }
    public function gzh_automsg_add()
     {
         admin_role_check($this->z_role_list,$this->mca,1);
         if(request()->isPost()){
             $data = request()->post();
             $data['ctime'] = time();
             $data['cuid'] = session('admin')['id'];
             $res = Db::name('wx_gzh_automsg')->insert($data);
            return ZFRetMsg($res,'新增成功','新增失败');
         }
         $cid = request()->get('cid',0);
         return view();
     }
    public function gzh_automsg_edit($id)
    {
        admin_role_check($this->z_role_list,$this->mca,1);
        if(request()->post()){
            $data = request()->post();
            $res = Db::name('wx_gzh_automsg')->where('id',$data['id'])->update($data);
            return ZFRetMsg($res,'更新成功','更新失败');
        }
        $res =  Db::name('wx_gzh_automsg')->where([['id','=',$id]])->find();
        $this->assign('res',$res);
        return view();
    }
    public function gzh_media(Request $request){
        admin_role_check($this->z_role_list,$this->mca);
        $this->conf(session('admin')['id']);
        $type = 'image';
        $offset = 0;
        $count = 20;
        $list = $this->app->material->list($type, $offset, $count);
        
        
        // dd($list);
        $this->assign('list',$list);
        $this->assign('type',$type);

        return view();


    }
    public function gzh_media_add(Request $request)
     {
         admin_role_check($this->z_role_list,$this->mca,1);
         if(request()->isPost()){
             $data = request()->post();
             $data['ctime'] = time();
             $data['cuid'] = session('admin')['id'];
             $res = Db::name('wx_gzh_media')->insert($data);
            return ZFRetMsg($res,'新增成功','新增失败');
             
         }
        $cid = request()->get('cid');
        $this->assign('cid',$cid);
        return view();

     }


    public function gzh_media_edit($id)
    {
        admin_role_check($this->z_role_list,$this->mca,1);
        if(request()->isPost()){
            $data = request()->post();
            $res = Db::name('wx_gzh_media')->where('id',$data['id'])->update($data);
            return ZFRetMsg($res,'更新成功','更新失败');
            
        }
        $res =  Db::name('wx_gzh_media')->where([['id','=',$id]])->find();
//        $plist = Db::name($this->tpl_config['cate_tb'])->where([['status','<>',9]])->order("id","asc")->paginate('10');
        $this->assign('res',$res);
        
        return view();

    }

    public function gzh_user(){
        admin_role_check($this->z_role_list,$this->mca,1);
        $this->conf(session('admin')['id']);
        $where[] = ['u.status','<>','9'];
        $where[] = ['u.openid','<>',''];
        // $list = Db::name('user as u')
        //             ->select('u.*','g.name as gname','u.ctime', 'u.tel as mobile')
        //             ->join('user_group as g', function ($join) {
        //                 $join->on('u.gid', '=', 'g.id')
        //                      ->where('g.status', '<>', 9);
        //             })
        //             ->where($where)
        //             ->order("u.id desc")
        //             ->paginate(10);
        $where[] = ['g.status','<>','9'];

        $list = Db::name('user u')
                    ->field('u.* , g.name as gname , u.ctime , u.tel as mobile')
                    ->join('zf_user_group g' ,'g.id=u.gid')
                    ->where($where)
                    ->order("u.id desc")
                    ->paginate(10);
        $page = $list->render();
        $this->assign("page",$page);
        $this->assign("list",$list);
        return view();
    }

    public function gzh_automsg_send(){
        admin_role_check($this->z_role_list,$this->mca,1);
        $openid = input('openid','');
        $list =  Db::name('wx_gzh_automsg_send_log')->where([['openid','=',$openid]])->order('ctime desc')->select();
        $this->assign('openid',$openid);
        $this->assign('list',$list);
        return view();

    }
    public function gzh_qrcode($cid=''){
        admin_role_check($this->z_role_list,$this->mca);
        if($cid!='' && $cid!='{cid'){
            $where[] = ['cid','=',$cid];
        }
        $where[] = ['status','<>',9];
        $where[] = ['cuid','=',session('admin')['id']];
        $list = Db::name('wx_gzh_qrcode')->where($where)->order("id desc")->paginate(10);
        $page = $list->render();
        $this->assign("page",$page);
        $this->assign('list',$list);
        $this->assign('cid',$cid);
        return view();
    }
    public function gzh_qrcode_add()
     {
         admin_role_check($this->z_role_list,$this->mca,1);
         if(request()->isPost()){
             $data = request()->post();
             $data['ctime'] = time();
             $data['cuid'] = session('admin')['id'];
            $this->conf(session('admin')['id']);
             if($data['day']!='0'){
                $data['type'] = '临时';
                if(intval($data['day']>30)){
                    return jserror('临时二维码时间最长30天');
                }
                $result = $this->app->qrcode->temporary($data['parm'], intval($data['day']) * 24 * 3600);
                $data['url'] = $this->app->qrcode->url($result['ticket']);
                if(!isset($data['url'])){
                    return jserror('生成二维码失败');
                }
                $data['etime'] = time()+intval($data['day']) * 24 * 3600;
             }else{
                $data['type'] = '永久';
                $result = $this->app->qrcode->forever($data['parm']);
                $data['url'] = $this->app->qrcode->url($result['ticket']);
                if(!isset($data['url'])){
                    return jserror('生成二维码失败');
                }
                $data['etime'] = 0;

             }

            
            $res = Db::name('wx_gzh_qrcode')->insert($data);
            return ZFRetMsg($res,'新增成功','新增失败');
         }
         $cid = request()->get('cid',0);
         return view();
     }
    public function gzh_qrcode_edit($id)
    {
        admin_role_check($this->z_role_list,$this->mca,1);
        if(request()->post()){
            $data = request()->post();
            $res = Db::name('wx_gzh_qrcode')->where('id',$data['id'])->update($data);
            return ZFRetMsg($res,'更新成功','更新失败');
        }
        $res =  Db::name('wx_gzh_qrcode')->where([['id','=',$id]])->find();
        $this->assign('res',$res);
        return view();
    }
    public function ajax_action(){
        //获取公众号全部用户openid
        $this->conf(session('admin')['id']);
        $act = request()->get('type','');
        if($act=='ajax_import_gzh_openid'){
            $list = Db::name('user')->where([['openid','<>','']])->order("id desc")->field('openid')->select();
            $_list = [];
            foreach ($list as $key => $value) {
                $_list[] = $value['openid'];
            }
            // 获取用户列表
            $gzh_list = $this->app->user->list(); 
            $appid = $this->g_res['gzh_app_id'];
            foreach($gzh_list['data']['openid'] as $k=>$vo){
                if(!in_array($vo, $_list)){
                    //新增
                    Db::name('user')->insert(['openid'=>$vo,'ctime'=>time(),'type'=>'导入','name'=>'未激活用户','appid'=>$appid]);
                }
            }
            return jssuccess('已导入');
        }elseif($act=='send_simple_gzhmsg'){
            //发送信息
            $data = request()->post();
            //保存用户搜索记录 
            $save_res['openid'] = $data['openid'];
            $save_res['event'] = '管理员主动发送';
            $save_res['keyword'] = '';
            $save_res['status'] = 1;
            $save_res['ctime'] = time();
            $save_res['send_ids'] = '';
            $save_res['send_content'] = $data['content'];
            $save_res['gzh_id'] = '';
            $id = Db::name('wx_gzh_automsg_send_log')->insertGetId($save_res);
            $res = $this->app->customer_service->message($data['content'])->to($data['openid'])->send();
            if($res['errmsg']=='ok'){
                return jssuccess('发送成功');
            }else{
                Db::name('wx_gzh_automsg_send_log')->where(['id'=>$id])->delete();
                return jserror('发送失败'.$res['errmsg']);
            }

        }elseif($act=='get_simple_user'){
            // 获取公众号用户信息
            $openid = request()->get('openid','');
            $user = $this->app->user->get($openid);
            $data['name'] = $user['nickname'];
            $data['nickName'] = $user['nickname'];
            $data['sex'] = $user['sex']==2?0:1;
            $data['pic'] = $user['headimgurl'];
            $r = Db::name('user')->where(['openid'=>$openid])->update($data);
            return ZFRetMsg($r,'获取成功','获取失败');
        }elseif($act=='qrcode'){
            // 创建二维码
            //临时
            $result = $this->app->qrcode->temporary('scanLogin@#@123', 6 * 24 * 3600);
            // 获取二维码网址
            $url = $this->app->qrcode->url($result['ticket']);
            dd($url);
            // // https://api.weixin.qq.com/cgi-bin/showqrcode?ticket=TICKET
            // 获取二维码内容
            // $url = $this->app->qrcode->url($ticket);
            // $content = file_get_contents($url); // 得到二进制图片内容
            // file_put_contents(__DIR__ . '/code.jpg', $content); // 写入文件




            $openid = request()->get('openid','');
            $user = $this->app->user->get($openid);
            $data['name'] = $user['nickname'];
            $data['nickName'] = $user['nickname'];
            $data['sex'] = $user['sex']==2?0:1;
            $data['pic'] = $user['headimgurl'];
            $r = Db::name('user')->where(['openid'=>$openid])->update($data);
            return ZFRetMsg($r,'获取成功','获取失败');
        }
    }

    
    private function conf($gid){
        if($gid==''){
            $this->app = app('wechat.official_account');
            $this->gid = '';
        }else{
            $this->gid = $gid;
            $g_res = Db::name('wx_config')->where([['uid','=',$gid]])->find();
            $this->g_res = $g_res;
            if(!$g_res){    echo '账号不存在'; die; }
            if($g_res['status']!=1){ echo '账户已被关闭';die; }
            $options = [
                'app_id'    => $g_res['gzh_app_id'],
                'secret'    => $g_res['gzh_secret'],
                'token'     => $g_res['gzh_token'],
                'aes_key' =>$g_res['gzh_aes_key']
            ];
            $this->app = Factory::officialAccount($options);
        }
    }


    public function test(){
        

    }
    


    
}
