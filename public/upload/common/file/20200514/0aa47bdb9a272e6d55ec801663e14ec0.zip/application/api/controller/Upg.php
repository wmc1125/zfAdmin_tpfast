<?php
// +----------------------------------------------------------------------
// | 子枫后台管理系统(TpFast系列)[基于ThinkPHP5.1开发]
// +----------------------------------------------------------------------
// | Copyright (c)  http://v1.fast.zf.90ckm.com/
// | 子枫后台管理系统提供免费使用,可使用此框架进行二次开发
// +----------------------------------------------------------------------
// | Author: 子枫 <287851074@qq.com>
// +----------------------------------------------------------------------
// | github:https://github.com/wmc1125/zfAdmin_tpfast
// | 码云:  https://gitee.com/wmc1125/zfAdmin_tpfast
// | Mc技术论坛: http://bbs.wangmingchang.com/forum.php?mod=forumdisplay&fid=77
// +----------------------------------------------------------------------

namespace app\api\controller;
use think\facade\Request;
use think\Db;
use think\Controller;

class Upg extends Controller
{
	public function index(){
		$data = request()->post();
		if($data==[]){
			return jserror('参数错误');
		}
		//判断用户,获取用户的基本信息

		//判断升级类型
		if($data['type'] = 'zf-tpfast'){
			return $this->system($data);
		}else{
			return $this->plugin($data);
		}
	}
	public function test(){
		dd(config()['version']);
	}

	//系统
	private function system($data){
		//比较版本

		//判断用户是否有权限

		//比较版本
		$id = Db::name('soft_plugins_post_version')->where(['title'=>$data['version'],'post_id'=>30])->value('id');
		if($id){
			//查询是否有新版本
			$res = Db::name('soft_plugins_post_version')->where([['id','>',$id],['post_id','=',$data['post_id']],['status','=',1],['file','<>','']])->order('id desc')->find();
			if($res){
				$ret['name'] = 'zf-tpfast';
				$ret['version'] = $data['version'];
				$ret['version_new'] = $res['title'];
				$ret['utoken'] = $res['file'];
				return jssuccess($ret);
			}else{
       			return jserror('无新版本');
			}
		}
        return jserror('当前版本不存在');

	}
	//插件
	private function plugin($data){
		//比较版本

		//判断用户是否有权限
	}
	public function down(){ 
		dd(111);
	}
}