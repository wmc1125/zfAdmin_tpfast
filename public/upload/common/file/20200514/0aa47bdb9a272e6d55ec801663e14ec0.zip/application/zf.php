<?php
// +----------------------------------------------------------------------
// | 子枫后台管理系统(TpFast系列)[基于ThinkPHP5.1开发]
// +----------------------------------------------------------------------
// | Copyright (c)  http://v1.fast.zf.90ckm.com/
// | 子枫后台管理系统提供免费使用,可使用此框架进行二次开发
// +----------------------------------------------------------------------
// | Author: 子枫 <287851074@qq.com>
// +----------------------------------------------------------------------
// | github:https://github.com/wmc1125/zfAdmin_tpfast
// | 码云:  https://gitee.com/wmc1125/zfAdmin_tpfast
// | Mc技术论坛: http://bbs.wangmingchang.com/forum.php?mod=forumdisplay&fid=77
// +----------------------------------------------------------------------


use think\facade\Hook;
/*

这是个加密的文件
加密项目必须
*/
// function zf($zz='0'){
//     switch ($zz) {
//         case 'zfadmin-fast':
//             $data['domain'] = request()->domain();//domain
//             $data['ip'] = request()->ip();//访问ip
//             $data['type'] = 2; //1 单域名  2 根域名  
//             $data['zfadmin'] = 'fast'; //版本类型  
//             $data['version'] = '1.0'; //版本号  
//             $data['time'] = time(); //版本号  
//             $auth_ret = https_post('http://mctool.wangmingchang.com/api/auth/web',['data'=>zf_encrypt(json_encode($data),"web_auth")]);
//             //判断是否通讯成功
//             if(json_decode($auth_ret)){
//                 //判断是否认证
//                 if(json_decode($auth_ret)->code==1){
//                     $is_auth_code = true;
//                 }else{
//                     $is_auth_code = false;
//                 }
//             }else{
//                 // 通讯失败,使用本地文件校验
//                 error_reporting(0);
//                 $_file = config()['zf_auth']['key'];
//                 // $_file = '3lfH0tLHyqJXblScZMfMz5LFop+Ej4Wr3KKeUnNmZYPdm8TH0s/PVm9WmMSn2IPf';//90ckm.com
//                 $f = json_decode(zf_decrypt($_file,'web_auth'));
//                 if($f && $_file){
//                     if($f->type == '1'){
//                         // dd(request()->domain());//http://v1.fast.zf.90ckm.com//单域名
//                         $is_auth_code = ($f->domain!=request()->domain()?false:true);
//                     }elseif($f->type == '2'){
//                         // dd(request()->rootDomain());//90ckm.com//根域名
//                         $is_auth_code = ($f->domain!=request()->rootDomain()?false:true);
//                     }else{
//                         $is_auth_code = false;
//                     }
//                 }else{
//                     $is_auth_code = false;
//                 }        
//             }
//             if(!$is_auth_code){
//                 die("<a target='_blank' href='http://bbs.wangmingchang.com/forum.php?mod=forumdisplay&fid=77&page=1'> 认证文件失效,请参考如下操作</a>");
//             }else{
//                 //认证成功,设置个session
//                 $zf_web_auth = $data;
//                 $zf_web_auth['code'] = 1;
//                 $zf_web_auth['auth'] = zf_encrypt(json_encode($data));
//                 // dd($zf_web_auth);
//                 session('zf_web_auth',$zf_web_auth);
//             }
//             return ['code'=>1,'auth'=>zf_encrypt('zfadmin-'.date("Y-m-d",time()))];
//             break;
//         default:
//             die("<a target='_blank' href='http://bbs.wangmingchang.com/forum.php?mod=forumdisplay&fid=77&page=1'> 获取授权</a>");        
//             break;
//     }
// }



class Zfyun 
{
    public function __construct (){
        //站点key
        $this->email = config()['zf_auth']['email'];//删除
        // $this->key = md5($this->email).mt_rand(100,999);
        $this->key = config()['zf_auth']['key'];
        $this->key = substr($this->key,0,32);
        $this->pro = '测试板块';
        // echo "当前key:".$this->key.'<br>'; 
        ####创建sc####
        // $this->create_sc();  //创建sc
        ####验证sc####
        if(!isset(config()['zf_auth']['sc']) || !isset(config()['zf_auth']['key']) ){
            echo '授权参数不存在 config/zf_auth.php'; die;
        }
        $this->sc = config()['zf_auth']['sc'];
        // $this->sc = 'roOmm9eVmJ2hzpiZ0VieUnFoxdGllJijpoiShseszqCYg21jmGhvcWeYbGmcYoaVrKHPy1qgZmlxnJ6Zm26abF+Dp6vTlVtzVMKjnIVihqCqp4SgWsKqap2ayMDZcMeXaL2oaJpnn5Wnlm5lmliQUp2lw8+kiG9Wa56dnJlplWpnoaSjkZOoplTe';//伪sc
        $this->check_sc();//验证sc
    }
    //检查key是否正确
    private function check_sc(){
        if($this->sc==''){
            $this->send_err('请提供sc'); die;
        }
        //解密
        $json_data = $this->zf_decrypt($this->sc,$this->key);
        $data = json_decode($json_data);
        if($data){
            //判断email
            if(md5($data->email)!=$this->key){
                $this->send_err('key值错误'); die;
            }
            //判断产品
            if($data->pro!=$this->pro){
                $this->send_err('未授权该产品'); die;
            }  
            //判断域名
            if($data->type=='all' && $data->site_domain!=''){
                //根域名一直即可
                if(strpos($_SERVER['HTTP_HOST'],$data->site_domain) !== false){ 
                    // '认证通过'; 
                }else{
                    $this->send_err('域名授权失败');die;
                }
            }else{
                if($data->site_domain!= $_SERVER['HTTP_HOST']){
                    $this->send_err('域名授权失败');die;
                }
            }
            //判断授权时间
            if($data->etime!=0 && $data->etime<=time()){
                $this->send_err('授权已到期');
                // header("Location: tencent://message/?uin=287851074&Site=&Menu-=yes");die;
            }
        }else{
                $this->send_err('未授权产品,sc/key错误'); die;
        }
        
    }
    // 发送错误信息
    private function send_err($err_data = ''){
        echo $err_data.'<br>';
        echo '请联系微信:wmc1125';die;
        $data['site_domain'] = '90ckm.com';
        // $data['site_ip'] = gethostbyname($_SERVER['HTTP_HOST']);
        $data['ctime'] = time();
        $data['pro'] = '测试板块';
        $data['msg'] = $err_data;
        @https_post('http://www.baidu.com',json_encode($data));
    }
    #############生成sc(删除ing)#############
    private function create_sc(){
        echo "---生成sc---<br>";
        $data['site_domain'] = '90ckm.com';
        // $data['site_ip'] = gethostbyname($_SERVER['HTTP_HOST']);
        $data['ctime'] = time();
        $data['etime'] = time()+36000; //0 不限制  时间戳
        $data['type'] = 'all';//all/simple
        $data['pro'] = '测试板块';
        $data['email'] = $this->email;
        $ret_str =  $this->zf_encrypt(json_encode($data),$this->key);
        echo "生成sc:".$ret_str."<br>";
        echo "---生成结束---<br>";
    }
   

    public function index()
    {
        // echo $this->key;
        // 加解密
        // echo "key:".$this->key;
        // echo "<br>";
        // echo "加密_str:".$this->zf_encrypt($this->key);
        // echo "<br>";
        // echo "解密_str:".$this->zf_decrypt($this->zf_encrypt($this->key));
        // echo "<br>";
        // // 域名/ip授权
        // echo $_SERVER['HTTP_HOST']; //域名
        // echo gethostbyname($_SERVER['HTTP_HOST']);//ip
        // $this->check_sc(); //验证sc
        // echo 'ok';

    }

    




    //加密
    private function zf_encrypt($data, $key='***********'){
        $key    =    md5($key);
        $x        =    0;
        $len    =    strlen($data);
        $l        =    strlen($key);
        $char = '';
        $str = '';
        for ($i = 0; $i < $len; $i++){
            if ($x == $l){
                $x = 0;
            }
            $char .= $key{$x};
            $x++;
        }
        for ($i = 0; $i < $len; $i++){
            $str .= chr(ord($data{$i}) + (ord($char{$i})) % 256);
        }
        return base64_encode($str);
    }
    //解密
    private function zf_decrypt($data, $key='***********'){
        $key = md5($key);
        $x = 0;
        $data = base64_decode($data);
        $len = strlen($data);
        $l = strlen($key);
        $char = '';
        $str = '';
        for ($i = 0; $i < $len; $i++){
            if ($x == $l){
                $x = 0;
            }
            $char .= substr($key, $x, 1);
            $x++;
        }
        for ($i = 0; $i < $len; $i++){
            if (ord(substr($data, $i, 1)) < ord(substr($char, $i, 1))){
                $str .= chr((ord(substr($data, $i, 1)) + 256) - ord(substr($char, $i, 1)));
            }
            else{
                $str .= chr(ord(substr($data, $i, 1)) - ord(substr($char, $i, 1)));
            }
        }
        return $str;
    }
    /*
    * 发起POST网络提交
    * @params string $url : 网络地址
    * @params json $data ： 发送的json格式数据
    */
    private function https_post($url,$data)
    {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        if (!empty($data)){
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        }
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($curl);
        curl_close($curl);
        return $output;
    }
     /*
    * 发起GET网络提交
    * @params string $url : 网络地址
    */
    private function https_get($url)
    {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE); 
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE); 
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE); 
        curl_setopt($curl, CURLOPT_HEADER, FALSE) ; 
        curl_setopt($curl, CURLOPT_TIMEOUT,60);
        if (curl_errno($curl)) {
            return 'Errno'.curl_error($curl);
        }
        else{$result=curl_exec($curl);}
        curl_close($curl);
        return $result;
    }

    //成功之后返回json
    private function jssuccess($msg, $url = 'back') {
        echo json_encode(array("msg" => $msg, "url" => $url, "result" => '1'));exit;
    }
    //失败之后返回json
    private function jserror($msg, $url = 'back') {
        echo json_encode(array("msg" => $msg, "url" => $url, "result" => '0'));exit;
    }
}

// $Zfyun  = new Zfyun();
// $zf_auth->auth();

?>