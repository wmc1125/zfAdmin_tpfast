<?php
// +----------------------------------------------------------------------
// | 子枫后台管理系统(TpFast系列)[基于ThinkPHP5.1开发]
// +----------------------------------------------------------------------
// | Copyright (c)  http://v1.fast.zf.90ckm.com/
// | 子枫后台管理系统提供免费使用,可使用此框架进行二次开发
// +----------------------------------------------------------------------
// | Author: 子枫 <287851074@qq.com>
// +----------------------------------------------------------------------
// | github:https://github.com/wmc1125/zfAdmin_tpfast
// | 码云:  https://gitee.com/wmc1125/zfAdmin_tpfast
// | Mc技术论坛: http://bbs.wangmingchang.com/forum.php?mod=forumdisplay&fid=77
// +----------------------------------------------------------------------

namespace app\demo\controller;
use think\Db;
use think\Controller;
use MongoDB\Driver\Manager;
use MongoDB\Collection;
use MongoDB\Client as MongoClient;
class Mongodb extends Controller
{
    public function index()
    {
        echo "index";
    }
    public function __construct()
    {
        // 连接数据库
        $this->connection  = new  MongoClient ();
    }
// https://docs.mongodb.com/php-library/current/tutorial/crud/
    public function test() {
        $collection  =  $this->connection -> v1_fast -> md5_data_1;   //选择数据库 -> 选择集合
        // $collection->find(); //查找集合所有数据
        $res = $collection->findOne(['username'=>'admin']);//查找一条数据
        dd($res);

// 增 单个
        // $insertOneResult = $collection->insertOne([
        //     'username' => 'admin',
        //     'email' => 'admin@example.com',
        //     'name' => 'Admin User',
        // ]);
        // printf("Inserted %d document(s)\n", $insertOneResult->getInsertedCount());
        // var_dump($insertOneResult->getInsertedId());

//增  多个
        // $insertManyResult = $collection->insertMany([
        //     [
        //         'username' => 'admin',
        //         'email' => 'admin@example.com',
        //         'name' => 'Admin User',
        //     ],
        //     [
        //         'username' => 'test',
        //         'email' => 'test@example.com',
        //         'name' => 'Test User',
        //     ],
        // ]);
        // printf("Inserted %d document(s)\n", $insertManyResult->getInsertedCount());
        // var_dump($insertManyResult->getInsertedIds());
      
//查
        $document = $collection->findOne(['user' => 'admin']);
        var_dump($document);




    }
    public function test2(){
        $collection  =  $this->connection -> v1_fast -> md5_data_1;   //选择数据库 -> 选择集合
        //查询  如果存在 调过
        $str = '11';
        $data['str'] = $str;
        $data['md5_str'] = md5($str);
        $data['ctime'] = date("Y-m-d H:i:s",time());
        $data['uid'] = 0;
        $data['status'] = 1;
        $data['type'] = 1;
        $is_res = $collection->findOne(['str'=>$data['str']]);//查找一条数据
        if(!$is_res){
            $issave = $collection->insertOne($data);
        }


        
    }

   

   
   


}
