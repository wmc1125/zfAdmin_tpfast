<?php
namespace app\crontab\command;
 
use think\console\Command;
use think\console\Input;
use think\console\input\Argument;
use think\console\input\Option;
use think\console\Output;
use think\Db;
use app\common\model\Md5Data;
use MongoDB\Client as MongoClient;

class Task extends Command
{
    protected function configure()
    {
        $this->setName('task')
            ->setDescription('定时计划：每天生成一个日期文件');
    }
 
    protected function execute(Input $input, Output $output)
    {
        // file_put_contents(time().'.txt', '当前日期为：'.date('Y-m-d'));
        // $data['name'] = time();
        // $data['time'] = date("Y-m-d H:i:s", time());
        // Db::name('test')->insert($data);

        // $ss=GetRandStr(6);
        // // dd($ss);
        // $data = [];
        // for ($i=0; $i < 1000 ; $i++) { 
        //     $data[$i]['md5_str'] = md5($i.$ss);
        //     $data[$i]['str'] = $i.$ss;
        //     $data[$i]['ctime'] =  date("Y-m-d H:i:s", time());
        //     if(!Db::name('md5_data_1')->where(['str'=> $data[$i]['str']])->find()){
        //         Db::name('md5_data_1')->insert($data[$i]);
        //     }
        //     $data[$i]['md5_str'] = md5($ss.$i);
        //     $data[$i]['str'] = $ss.$i;
        //     $data[$i]['ctime'] =  date("Y-m-d H:i:s", time());
        //     if(!Db::name('md5_data_1')->where(['str'=> $data[$i]['str']])->find()){
        //         Db::name('md5_data_1')->insert($data[$i]);
        //     }
        // }



###############
        //分表
        // $Md5DataModel = new Md5Data();
        // for($i = 1; $i < 1000; $i++){
        //     $str = GetRandStr(10);
        //     $data = [
        //         'uid' => 0,
        //         'status'=>1,
        //         'ctime' => date("Y-m-d H:i:s", time()),
        //         'str' => $str,
        //         'md5_str' => md5($str)
        //     ];
        //     if(!$Md5DataModel->find_all( ['str'=>$str])){
        //         $Md5DataModel->saveData($data, $i);
        //     }


        //     $data = [
        //         'uid' => 0,
        //         'status'=>1,
        //         'ctime' => date("Y-m-d H:i:s", time()),
        //         'str' => $str.$i,
        //         'md5_str' => md5($str.$i)
        //     ];
        //     if(!$Md5DataModel->find_all( ['str'=>$str.$i])){
        //         $Md5DataModel->saveData($data, $i);
        //     }

        //     $data = [
        //         'uid' => 0,
        //         'status'=>1,
        //         'ctime' => date("Y-m-d H:i:s", time()),
        //         'str' => $i.$str,
        //         'md5_str' => md5($i.$str)
        //     ];
        //     if(!$Md5DataModel->find_all( ['str'=>$i.$str])){
        //         $Md5DataModel->saveData($data, $i);
        //     }
        // }
        // echo 'success';die;

#mongodb
        $this->connection  = new  MongoClient ();
        $collection  =  $this->connection -> v1_fast -> md5_data_1;   //选择数据库 -> 选择集合
        //查询  如果存在 调过
        // $str = '11';
        // $data['str'] = $str;
        // $data['md5_str'] = md5($str);
        // $data['ctime'] = date("Y-m-d H:i:s",time());
        // $data['uid'] = 0;
        // $data['status'] = 1;
        // $data['type'] = 1;
        // $is_res = $collection->findOne(['str'=>$data['str']]);//查找一条数据
        // if(!$is_res){
        //     $issave = $collection->insertOne($data);
        // }




        for($i = 1; $i < 100; $i++){
            $str = GetRandStr(10);
            $data = [
                'uid' => 0,
                'status'=>1,
                'ctime' => date("Y-m-d H:i:s", time()),
                'str' => $str,
                'md5_str' => md5($str),
                'type'=>1
            ];
            $is_res = $collection->findOne(['str'=>$data['str']]);//查找一条数据
            if(!$is_res){
                $issave = $collection->insertOne($data);
            }

            $data = [
                'uid' => 0,
                'status'=>1,
                'ctime' => date("Y-m-d H:i:s", time()),
                'str' => $str.$i,
                'md5_str' => md5($str.$i),
                'type'=>1
            ];
            $is_res = $collection->findOne(['str'=>$data['str']]);//查找一条数据
            if(!$is_res){
                $issave = $collection->insertOne($data);
            }

            $data = [
                'uid' => 0,
                'status'=>1,
                'ctime' => date("Y-m-d H:i:s", time()),
                'str' => $i.$str,
                'md5_str' => md5($i.$str),
                'type'=>1
            ];
            $is_res = $collection->findOne(['str'=>$data['str']]);//查找一条数据
            if(!$is_res){
                $issave = $collection->insertOne($data);
            }
            
        }
        echo 'success';die;
        



    }
 
}
function GetRandStr($length){
    $str='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $len=strlen($str)-1;
    $randstr='';
    for($i=0;$i<$length;$i++){
    $num=mt_rand(0,$len);
    $randstr .= $str[$num];
    }
    return $randstr;
}
