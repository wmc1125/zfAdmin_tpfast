<?php
	$config = [
		'name'=>'演示站点',
		'theme_name'=>'def',
		'version'=>'v1.0.0',
		'pic'=>'http://oss1.wangmingchang.com/mac/MdImd/20200528081400.png',
		'ctime'=>'2019-7-24',
		'summary'=>'',
		'author'=>'子枫'
	];
