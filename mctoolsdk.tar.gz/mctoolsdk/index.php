<?php
require 'vendor/autoload.php';

//$auth = new Wmc1125\Mctoolsdk\IndexController();
//$auth->index();

$auth2 = new Wmc1125\Mctoolsdk\Mctool();
$auth2->index();