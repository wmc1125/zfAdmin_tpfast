<?php /*a:2:{s:75:"/www/wwwroot/v1.fast.zf.90ckm.com/application/admin/view/index/welcome.html";i:1591844561;s:73:"/www/wwwroot/v1.fast.zf.90ckm.com/application/admin/view/public/load.html";i:1590119785;}*/ ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title><?php echo htmlentities($web_config['version']['ver_name']); ?></title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
  <link rel="stylesheet" href="/vendor/wmc1125/tpfast-public/public/static/style/layui/css/layui.css" media="all">
  <link rel="stylesheet" href="/vendor/wmc1125/tpfast-public/public/static/system/style/admin.css" media="all">
</head> 

<body  >
<style type="text/css">
  /* 
----------------------------------
- Preloader
----------------------------------
*/

.preloader-wrap {
    position: fixed;
    width: 100%;
    height: 100%;
    background: #fff;
    z-index: 10000;
    text-align: center;
    display: table;
}
.preloader-inside {
    position: relative;
    height: auto;
    width: 200px;
    margin-top: 300px;
    vertical-align: middle;
    text-align: center;
    display: table-cell;
    color: #fff;
}
.spinner {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    position: relative;
    display: inline-block;
}
.spinner img {
    position: absolute;
    top: 22px;
    left: 0;
    padding: 5px;
}
.spinner:after {
    content: "";
    display: block;
    width: 80px;
    height: 80px;
    border-radius: 50%;
}
.spinner:before {
    content: "";
    display: block;
    width: 80px;
    height: 80px;
    border-radius: 50%;
}
.spinner-1:after {
    position: absolute;
    top: 0px;
    left: 0px;
    border: 4px solid transparent;
    border-top-color: #08ada7;
    border-bottom-color: #08ada7;
    animation: spinny 2s linear infinite;
}
@keyframes spinny {
    0% {
        transform: rotate(0deg) scale(1);
    }
    50% {
        transform: rotate(30deg) scale(1.2);
    }
    100% {
        transform: rotate(360deg) scale(1);
    }
}
</style>
<!-- Preloader -->
<div class="preloader-wrap">
    <div class="preloader-inside">
        <div class="spinner spinner-1">
            <!-- <img src="https://i.loli.net/2020/05/22/b7xFrUPE4VW9DAi.png" alt="responsive img"> -->
        </div>
    </div>
</div>
<!-- End Preloader -->
  <script src="/vendor/wmc1125/tpfast-public/public/static/style/jquery-1.8.3.min.js"></script>  

<script type="text/javascript">
      $(window).on('load', function() {
        $('.preloader-wrap').fadeOut('slow', function() { $(this).remove(); });
      });
  // Js Index
    // Preloader
</script>
  <div class="layui-fluid">
    <div class="layui-row layui-col-space15">
      <div class="layui-col-md12">
        <blockquote class="layui-elem-quote layui-bg-green">
          <div id="nowTime">亲爱的<?php echo htmlentities(app('session')->get('admin.name')); ?> 欢迎使用子枫后台管理系统(Tp5系列)模版,在使用过程中有什么问题,可以在<a class="layui-btn layui-btn-xs" href="http://bbs.wangmingchang.com/forum.php?mod=forumdisplay&fid=77" target="_blank">Mc技术论坛</a>留言。当前时间为： <span id="datetime"></span> </div>
        </blockquote>
      </div>
      
      <div class="layui-col-md8">
        <div class="layui-card">
          <div class="layui-card-header">版本信息</div>
          <div class="layui-card-body layui-text">
            <table class="layui-table">
              <colgroup>
                <col width="100">
                <col>
              </colgroup>
              <tbody>
                <tr>
                  <td>当前版本</td>
                  <td>
                    
                      <a href="http://bbs.wangmingchang.com/forum.php?mod=forumdisplay&fid=77" target="_blank" >子枫后台管理系统(Tp5系列)<?php echo config()['version']['version']; ?></a>
                  </td>
                </tr>
                <tr>
                  <td>基于框架</td>
                  <td>
                    <a href="http://www.thinkphp.cn"  target="_blank" >Tp5.1</a> + <a href="https://www.layui.com" target="_blank" >layui</a> + <a href="https://gitee.com/yinqi/Light-Year-Admin-Template" target="_blank" >光年后台模板</a>
                </td>
                </tr>
                <tr>
                  <td>主要特色</td>
                  <td>零门槛 / 响应式 / 清爽 / 极简 / 快速开发</td>
                </tr>
                <tr>
                  <td>获取渠道</td>
                  <td style="padding-bottom: 0;">
                    <div class="layui-btn-container">
                      <a href="http://bbs.wangmingchang.com/forum.php?mod=forumdisplay&fid=77" target="_blank" class="layui-btn layui-btn-danger">子枫后台系统</a>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div class="layui-row layui-col-space15">
          
          <div class="layui-col-sm12 layui-col-md12">

            <div class="layui-card">
              <div class="layui-card-header">服务器信息</div>
              <div class="layui-card-body layui-text">
                <table class="layui-table">
                  <colgroup>
                    <col width="400">
                    <col width="300">
                    <col>
                  </colgroup>
                  <tbody>
                    <tr>
                      <td>站点信息:</td>
                      <td>
                          <?php echo $_SERVER["SERVER_NAME"];?>(IP:<?php echo $_SERVER["SERVER_ADDR"];?>)
                      </td>
                    </tr>
                    
                    <tr>
                      <td>服务器：</td>
                      <td>
                        <?php echo php_uname('s').' '.php_uname('r');?>
                      </td>
                    </tr>
                    <tr>
                      <td>站点物理路径：</td>
                      <td>
                        <?php echo $_SERVER['DOCUMENT_ROOT'];?>
                      </td>
                    </tr>
                    <tr>
                      <td>POST大小：</td>
                      <td>
                        <?php echo ini_get('max_execution_time').'M';?>
                      </td>
                    </tr>
                      <tr>
                      <td>上传大小：</td>
                      <td>
                        <?php echo ini_get('upload_max_filesize');?>
                      </td>
                    </tr>
                      <tr>
                      <td>服务器时间：</td>
                      <td>
                        <?php echo date('Y-m-d H:i:s');?>
                      </td>
                    </tr>
                    
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        
      </div>
      
        <div class="layui-col-md4">
          <div class="layui-card ">
            <div class="layui-tab layui-tab-brief layadmin-latestData">
              <div class="layui-card-header">后台插件推荐(微信号:zifeng1788)</div>
              <div class="layui-card-body layui-text">
    				<div class="layui-row layui-col-space15">
       					<div class="layui-col-md6">
            	 			<img style="width:139px;" src="http://oss1.wangmingchang.com/0bd86e854d29ca97c3510e774d9cd4d4/public/admin/images/2020-02-12/24172php7Z6xgm1581496724200212.jpeg">
       					</div>
       					<div class="layui-col-md6">
       						不定期会在朋友圈更新一些使用的插件,添加成功直接查看朋友圈即可<br>
       						也可以私人订制,网站开发/小程序开发/页面设计
       					</div>


    				</div>
          	  </div>

              
            </div>
          </div>

          <div class="layui-card ">
            <div class="layui-tab layui-tab-brief layadmin-latestData">
              <div class="layui-card-header">作者都在用的产品</div>
              <div class="layui-card-body layui-text">
              	
              	<div style="margin-bottom: 10px" >
              		<a href="https://www.aliyun.com/minisite/goods?userCode=cbkerf3s" target="_blank">
	            	 	<img style="width: 100%" src="http://oss1.wangmingchang.com/box/2020aliyunshangyun.jpg">
	            	</a>
              	</div>
              	
            	


              </div>
              
              
            </div>
          </div>

      
        </div>
      </div>

  <script src="/vendor/wmc1125/tpfast-public/public/static/style/layui/layui.js?t=1"></script>  
  <script src="/vendor/wmc1125/tpfast-public/public/static/system/common.js"></script>  

  <script>
   layui.use(['layer'],function(){
      var $ = layui.$

    });
 setInterval("document.getElementById('datetime').innerHTML=new Date().toLocaleString();", 1000);

  </script>
</body>
</html>

