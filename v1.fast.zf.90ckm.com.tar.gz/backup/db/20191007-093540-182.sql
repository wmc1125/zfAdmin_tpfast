-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #182
-- Date : 2019-10-07 09:35:40
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `zf_admin_log` VALUES ('182', 'admin/common/value_edit', '1565923176', '222.69.227.221', '1', '{\"id\":\"104\",\"dbname\":\"admin_role\",\"field\":\"sort\",\"value\":\"1\"}', '0');
