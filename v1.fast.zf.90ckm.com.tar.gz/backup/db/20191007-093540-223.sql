-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #223
-- Date : 2019-10-07 09:35:40
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `zf_admin_log` VALUES ('223', 'admin/products/product', '1565923924', '222.69.227.221', '1', '{\"page\":\"3\"}', '0');
