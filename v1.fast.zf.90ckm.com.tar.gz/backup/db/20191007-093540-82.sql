-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #82
-- Date : 2019-10-07 09:35:40
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `zf_admin_log` VALUES ('82', 'admin/products/order_detail', '1565922031', '222.69.227.221', '1', '{\"id\":\"62\",\"summary\":\"\",\"number\":\"1\",\"money\":\"60\",\"kd_company\":\"1\",\"kd_code\":\"\"}', '0');
