-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #81
-- Date : 2019-10-07 09:35:40
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `zf_admin_log` VALUES ('81', 'admin/products/order_detail', '1565922026', '222.69.227.221', '1', '{\"id\":\"62\"}', '0');
