-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #2826
-- Date : 2019-10-07 09:35:43
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `zf_category` VALUES ('426', '0', '1', '关于我', '', '', '', '', '', '', '1', '9', '1', '1563961521', '0', '<p>这是一个测试站点</p>', 'tpl_page', '', '10', '', '', '', '', '');
