-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #469
-- Date : 2019-10-07 09:35:41
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `zf_admin_log` VALUES ('469', 'admin/category/post_add', '1568094664', '58.39.19.183', '1', '{\"cid\":\"415\",\"title\":\"\",\"author\":\"\\u533f\\u540d\",\"ctime\":\"2019-09-10 13:50:42\",\"sort\":\"0\",\"pic\":\"\",\"save_content_pic\":\"0\",\"content\":\"<p><img src=\\\"https:\\/\\/zf-demo-test.oss-cn-beijing.aliyuncs.com\\/demo_zf_test\\/upload\\/image\\/20190910\\/1568094657200677.jpg\\\" style=\\\"\\\" title=\\\"1568094657200677.jpg\\\"\\/><\\/p><p><img src=\\\"https:\\/\\/zf-demo-test.oss-cn-beijing.aliyuncs.com\\/demo_zf_test\\/upload\\/image\\/20190910\\/1568094657800704.jpg\\\" style=\\\"\\\" title=\\\"1568094657800704.jpg\\\"\\/><\\/p><p><br\\/><\\/p>\"}', '1');
