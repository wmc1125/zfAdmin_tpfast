-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #2325
-- Date : 2019-10-07 09:35:42
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `zf_admin_log` VALUES ('2325', 'admin/common/del_post', '1570405651', '112.65.62.203', '1', '{\"id\":\"97\",\"db\":\"admin_role\"}', '1');
