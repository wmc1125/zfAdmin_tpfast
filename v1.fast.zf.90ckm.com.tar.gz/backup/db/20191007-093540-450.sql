-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #450
-- Date : 2019-10-07 09:35:41
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `zf_admin_log` VALUES ('450', 'admin/category/category_edit', '1568093755', '58.39.19.183', '1', '{\"cid\":\"415\",\"t\":\"0\",\"name\":\"\\u7d20\\u6750\",\"ename\":\"\",\"sname\":\"\",\"keyword\":\"\",\"url\":\"\",\"tpl_category\":\"tpl_list\",\"tpl_post\":\"tpl_content\",\"page\":\"10\",\"target\":\"\",\"summary\":\"\",\"icon\":\"\",\"pic\":\"\",\"file\":\"\",\"mid\":\"13\",\"pid\":\"0\",\"sort\":\"6\",\"append\":\"\",\"content\":\"<p><sup>a<\\/sup><sub>a<\\/sub>a<sub>a<\\/sub>a<sub>a<\\/sub>a<br\\/><\\/p>\"}', '1');
