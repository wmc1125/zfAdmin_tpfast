-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #2564
-- Date : 2019-10-07 09:35:43
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `zf_admin_log` VALUES ('2564', 'admin/category/post_edit', '1570410902', '112.65.62.203', '10', '{\"cid\":\"425\",\"id\":\"248\",\"title\":\"hello.world!\",\"summary\":\"\\u8fd9\\u662f\\u7b2c\\u4e00\\u7bc7\\u6587\\u7ae0\",\"author\":\"\\u533f\\u540d\",\"ctime\":\"2019-09-27 18:13:31\",\"sort\":\"0\",\"append\":\"\",\"pic\":\"http:\\/\\/zf-demo-test.oss-cn-beijing.aliyuncs.com\\/demo_zf_test\\/upload\\/simple\\/image\\/20190927\\/1569579364_moren_upload.png\",\"file\":\"\",\"content\":\"<p>\\u8fd9\\u662f\\u7b2c\\u4e00\\u7bc7\\u6587\\u7ae0<\\/p>\"}', '1');
