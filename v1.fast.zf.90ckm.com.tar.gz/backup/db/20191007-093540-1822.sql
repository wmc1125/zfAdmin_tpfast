-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #1822
-- Date : 2019-10-07 09:35:42
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `zf_admin_log` VALUES ('1822', 'admin/index/welcome', '1569569394', '58.39.19.183', '1', '[]', '1');
