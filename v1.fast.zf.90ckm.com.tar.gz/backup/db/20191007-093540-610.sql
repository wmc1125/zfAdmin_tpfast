-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #610
-- Date : 2019-10-07 09:35:41
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `zf_admin_log` VALUES ('610', 'admin/category/post_edit', '1568165679', '58.39.19.183', '1', '{\"cid\":\"415\",\"id\":\"246\",\"title\":\"2\",\"summary\":\"\",\"author\":\"\\u533f\\u540d\",\"ctime\":\"2019-09-10 17:06:26\",\"sort\":\"0\",\"append\":\"\",\"pic\":\"http:\\/\\/zf-demo-test.oss-cn-beijing.aliyuncs.com\\/demo_zf_test\\/upload\\/simple\\/image\\/20190911\\/1568165676_u%3D1465412230%2C84194476%26fm%3D27%26gp%3D0.jpg\",\"file\":\"http:\\/\\/zf-demo-test.oss-cn-beijing.aliyuncs.com\\/demo_zf_test\\/upload\\/simple\\/image\\/20190911\\/1568165669_MP_verify_28jPt6lRf6o6f6q7.txt\",\"content\":\"<p><img src=\\\"https:\\/\\/zf-demo-test.oss-cn-beijing.aliyuncs.com\\/demo_zf_test\\/upload\\/image\\/20190910\\/1568106391489156.jpg\\\" title=\\\"1568106391489156.jpg\\\" alt=\\\"basicprofile.JPG\\\"\\/><\\/p>\"}', '1');
