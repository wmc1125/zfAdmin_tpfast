-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #2702
-- Date : 2019-10-07 09:35:43
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `zf_admin_log` VALUES ('2702', 'admin/user/group_edit', '1570411928', '112.65.62.203', '10', '{\"id\":\"1\",\"name\":\"\\u9ad8\\u7ea7\\u4f1a\\u5458\",\"sort\":\"0\",\"user\":\"group_edit\"}', '1');
