-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #750
-- Date : 2019-10-07 09:35:41
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `zf_admin_log` VALUES ('750', 'admin/products/product_sku_edit', '1568184444', '58.39.19.183', '1', '{\"id\":\"2\"}', '1');
