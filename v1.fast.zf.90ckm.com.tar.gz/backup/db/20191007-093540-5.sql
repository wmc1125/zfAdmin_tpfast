-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #5
-- Date : 2019-10-07 09:35:40
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `zf_admin` VALUES ('10', '9', 'test', '96e79218965eb72c92a549dd5a330112', '', '', '', '', '', '1', '0', '', '0', '', '1', '', '0', '');
