-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #2443
-- Date : 2019-10-07 09:35:42
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `zf_admin_log` VALUES ('2443', 'admin/category/category_model_edit', '1570407850', '112.65.62.203', '10', '{\"id\":\"1\",\"name\":\"\\u5355\\u9875\\u6a21\\u578b\",\"model\":\"simple\",\"sort\":\"1\",\"status\":\"1\",\"ategory\":\"category_model_edit\"}', '1');
