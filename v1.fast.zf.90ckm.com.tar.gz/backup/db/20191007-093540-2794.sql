-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #2794
-- Date : 2019-10-07 09:35:43
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `zf_admin_role` VALUES ('123', '优化数据表', 'Mysql/optimize', '1', '1', '', '0', '115', 'Mysql', 'optimize', '1');
