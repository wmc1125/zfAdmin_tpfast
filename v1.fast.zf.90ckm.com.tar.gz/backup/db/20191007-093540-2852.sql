-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #2852
-- Date : 2019-10-07 09:35:43
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `zf_user` VALUES ('412', '222', 'e10adc3949ba59abbe56e057f20f883e', 'admin', '', '0', '0', '', '1', '1', '', '0', '1569478144', '1', '', '', '', '', '', '');
