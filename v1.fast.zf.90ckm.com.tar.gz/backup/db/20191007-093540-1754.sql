-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #1754
-- Date : 2019-10-07 09:35:42
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `zf_admin_log` VALUES ('1754', 'admin/mysql/index', '1569568244', '58.39.19.183', '1', '{\"group\":\"export\",\"page\":\"1\",\"limit\":\"10\"}', '1');
