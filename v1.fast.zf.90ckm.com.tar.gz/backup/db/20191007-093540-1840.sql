-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #1840
-- Date : 2019-10-07 09:35:42
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `zf_admin_log` VALUES ('1840', 'admin/mysql/import', '1569569904', '58.39.19.183', '1', '[]', '1');
