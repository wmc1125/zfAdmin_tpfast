-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #2822
-- Date : 2019-10-07 09:35:43
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `zf_advert` VALUES ('11', '1', 'https://timgsa.baidu.com', '10', '0', 's', '', '', '', '', 'https://demo.zf.90ckm.com/upload/file/20190724/7b5abb5ec820ebf22ec1d5974571ff4c.jpg', '0', '', '0', '1');
