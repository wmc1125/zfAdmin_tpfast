-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #891
-- Date : 2019-10-07 09:35:41
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `zf_admin_log` VALUES ('891', 'admin/config/admin_role_edit', '1568255875', '58.39.19.183', '1', '{\"id\":\"77\",\"name\":\"\\u5c0f\\u7a0b\\u5e8f\",\"value\":\"Xcx\\/\",\"pid\":\"96\",\"sort\":\"10\",\"menu\":\"1\",\"config\":\"admin_role_edit\"}', '1');
