-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #20
-- Date : 2019-10-07 09:35:40
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `zf_admin_log` VALUES ('20', 'admin/category/post_edit', '1565920474', '222.69.227.221', '1', '{\"cid\":\"415\",\"id\":\"227\",\"title\":\"\\u6587\\u7ae0\\u6d4b\\u8bd5\",\"summary\":\"\",\"author\":\"\\u533f\\u540d\",\"ctime\":\"2019-08-05 14:08:29\",\"sort\":\"0\",\"append\":\"\",\"pic\":\"http:\\/\\/demo.zf.90ckm.com\\/upload\\/file\\/water\\/20190805140847_8021.png\",\"file\":\"\",\"content\":\"<p><span style=\\\";font-family:\\u5b8b\\u4f53;font-size:14px\\\">11<\\/span><\\/p><p><span style=\\\";font-family:\\u5b8b\\u4f53;color:rgb(0,0,255);font-size:14px\\\">As<span style=\\\"font-family:\\u5b8b\\u4f53\\\">\\u8428\\u8fbe<\\/span><\\/span><span style=\\\";font-family:\\u5b8b\\u4f53;font-size:14px\\\"><span style=\\\"font-family:\\u5b8b\\u4f53\\\">\\u6253\\u6492\\u591a\\u6492\\u591a<\\/span><\\/span><\\/p><p><span style=\\\";font-family:\\u5b8b\\u4f53;font-size:14px\\\">&nbsp;<\\/span><\\/p><p><img src=\\\"http:\\/\\/demo.zf.90ckm.com\\/upload\\/image\\/20190807\\/1565146587837123.jpg\\\" title=\\\"1565146587837123.jpg\\\" alt=\\\"wps11.jpg\\\"\\/><span style=\\\";font-family:Calibri;font-size:14px\\\">&nbsp;<\\/span><\\/p><p><span style=\\\";font-family:\\u5b8b\\u4f53;font-size:14px\\\">11<\\/span><\\/p><p><img src=\\\"http:\\/\\/demo.zf.90ckm.com\\/upload\\/image\\/20190807\\/1565146602264897.jpg\\\" title=\\\"1565146602264897.jpg\\\" alt=\\\"wps12.jpg\\\"\\/><span style=\\\";font-family:Calibri;font-size:14px\\\">&nbsp;<\\/span><\\/p><p><span style=\\\";font-family:\\u5b8b\\u4f53;font-size:14px\\\"><span style=\\\"font-family:\\u5b8b\\u4f53\\\">\\u5927\\u98d2\\u98d2\\u7684<\\/span><\\/span><\\/p><p><br\\/><\\/p>\"}', '0');
