-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #724
-- Date : 2019-10-07 09:35:41
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `zf_admin_log` VALUES ('724', 'admin/category/category_model', '1568183905', '58.39.19.183', '1', '[]', '1');
