-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #3
-- Date : 2019-10-12 19:59:27
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

-- -----------------------------
-- Records of `zf_admin`
-- -----------------------------
