-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #2182
-- Date : 2019-10-07 09:35:42
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `zf_admin_log` VALUES ('2182', 'admin/user/admin_info', '1570178579', '112.65.62.203', '1', '{\"id\":\"1\",\"pic\":\"http:\\/\\/demo.zf.90ckm.com\\/upload\\/file\\/water\\/20190910112514_6109.png\",\"google_secret\":\"Y67N442CU2G4CIAG\",\"google_is\":\"0\"}', '1');
