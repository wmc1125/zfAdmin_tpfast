-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : v1_fast_zf_90ckm
-- 
-- Part : #2716
-- Date : 2019-10-07 09:35:43
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `zf_admin_log` VALUES ('2716', 'admin/mysql/export', '1570412140', '112.65.62.203', '10', '{\"id\":[\"zf_admin\",\"zf_admin_group\",\"zf_admin_log\",\"zf_admin_role\",\"zf_advert\",\"zf_category\",\"zf_category_model\",\"zf_config\",\"zf_guessbook\",\"zf_link\",\"zf_post\",\"zf_user\",\"zf_user_group\"]}', '1');
