<?php

Route::get('', 'index/def.index/index');
Route::get('index', 'index/def.index/index');
Route::get('list', 'index/def.cate/listt');
Route::get('detail', 'index/def.cate/detail');