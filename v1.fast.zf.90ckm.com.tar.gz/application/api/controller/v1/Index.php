<?php
namespace app\api\controller\v1;
use \think\Config;
// 版本1  v1
class Index
{
    public function index()
    {
        echo "api首页";
        

    }


   
    
}
