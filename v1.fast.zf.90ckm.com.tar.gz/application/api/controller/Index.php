<?php

/**
 * @Author: Eric-枫
 * @Date:   2019-09-04 13:55:24
 * @Last Modified by:   Eric-枫
 * @Last Modified time: 2019-09-04 13:56:25
 */
namespace app\api\controller;
/**
 * 
 */
class Index
{
	public function index(){

	}
}