<?php
namespace addons;
use think\Controller;
use zf\ZfAuth;
use think\Db;

class AdFunction extends Controller
{
	public function __construct (  )
    {
        parent::__construct();
        //判断是否认证
        if(!isset(config()['zf_auth']['key']) || !isset(config()['zf_auth']['sc']) || !isset(config()['zf_auth']['email']) ||  config()['zf_auth']['key']=='' ||  config()['zf_auth']['sc']=='' ||  config()['zf_auth']['email']=='' ){
            $this->error('请先认证系统','admin/login/authentication_sys'); 
        }
        $auth_info['sc'] = config()['zf_auth']['sc'];
        $auth_info['key'] = config()['zf_auth']['key'];
        $auth_info['post_id'] = config()['version']['post_id'];
        //验证权限
        $this->zfauth = new ZfAuth();
        $this->zfauth->vfast_check($auth_info,'alert');
        $this->zfauth->plugin_check($auth_info,'alert');
    }


    //导入数据表
    public function sql_tb($tb,$sql){
        $isTable = Db::query("SHOW TABLES LIKE '".$tb."'");
        if(!$isTable){
            $r = Db::execute($sql);
            if(!$r){
                return false;exit;
            }
        }
        return true;
    }

    /**
        $AdFunction = new \addons\AdFunction();
        $data = $AdFunction->get_config('zf_upgrade','data');
    插件名   
    文件名

    */

    public static function get_config($plugin_name,$file_name){
        $file = './addons/'.$plugin_name.'/config/'.$file_name.'.php';
        if(file_exists($file)){
            $data = require $file;
            return $data;
        }
        return null;
    }
    
    /**
        $AdFunction = new \addons\AdFunction();
        $res = $AdFunction->save_config(input('post.'),'zf_upgrade','data');
    数据
    插件名
    文件名

    */

    public static function save_config($arr = [], $plugin_name='',$file_name = ''){
        if (is_array($arr)) {
            $filename = $file_name . '.php';
            $filepath ='./addons/'.$plugin_name.'/config/' . $filename;
            if (!file_exists($filepath)) {
                $conf = "<?php return [];";
                file_put_contents($filepath, $conf);
            }
            $conf = include $filepath;
            foreach ($arr as $key => $value) {
                $conf[$key] = $value;
            }
            $time = date('Y/m/d H:i:s');
             $str = '<?php
// 插件信息最后修改于 '.$time;
             $str .= "  \r\n  \r\n return [\r\n";

            foreach ($conf as $key => $value) {
                $str .= "\t'$key' => '$value',";
                $str .= "\r\n";
            }
            $str .= '];';

            file_put_contents($filepath, $str);
            
            return true;
        } else {
            return false;
        }
    }

   
   


}


