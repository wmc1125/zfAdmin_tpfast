<?php
namespace addons\zf_upgrade\controller;
use addons\zf_upgrade\controller\Plugin;
use addons\Base;
class Index extends Base
{
    public function __construct (  ){
        parent::__construct();
        $AdFunction = new \addons\AdFunction();
        $data = $AdFunction->get_config('zf_upgrade','data');

        $this->upg_url = $data['upg_url'];  
        $this->upg_data = [
            'version'=> config()['version']['version'],
            'post_id'=> config()['version']['post_id'],
            'key'=> config()['zf_auth']['key'],
            'sc'=> config()['zf_auth']['sc'],
        ];
        $this->pulg_data_path = $data['pulg_data_path'];

        //进行比较的目录
        $this->temp_dir_list = explode(',', $data['temp_dir_list']);
        //备份的文件路径
        $_bak_path = [];  
        foreach ($this->temp_dir_list as $k => $vo) {
            $_bak_path  = array_merge( $_bak_path ,listdir('./'.$vo));
        }
        $this->bak_path = array_merge($_bak_path);  
        $this->assign('upg_url',$this->upg_url);
        $this->assign('upg_data',$this->upg_data);
        $this->assign('pulg_data_path',$this->pulg_data_path);
        $this->assign('temp_dir_list',$this->temp_dir_list);
        $this->assign('bak_path',$this->bak_path);

    }
    public function setting(){
        $AdFunction = new \addons\AdFunction();

        if(request()->isPost()){
            $data = input('post.');
            $res = $AdFunction->save_config(input('post.'),'zf_upgrade','data');
            if($res){
                return jssuccess('保存成功');die;
            }else{
                return jserror('保存失败');die;
            }   
        }

        //获取data.config
        $data = $AdFunction->get_config('zf_upgrade','data');
        $this->assign("data",$data);
        return view();
    }
    public function index(){
        $ret = $this->ZFUpgradeListFile();
        $this->assign('ret',$ret);
        //检测版本
        $url = $this->upg_url;
        $data = $this->upg_data;
        $ret = https_post($url,$data);
        $rr = json_decode($ret);
        if($rr){
            if( $rr->result==1 ){
                $upg_msg= ['code'=>1,'msg'=>$rr->msg->version_new];
            }else{
                $upg_msg= ['code'=>0,'msg'=>config()['version']['version'].' &nbsp<span style="color:red">'.$rr->msg.'</span>'];
            }
        }else{
                $upg_msg= ['code'=>0,'msg'=>'通讯失败'];
        }
        $this->assign('upg_msg',$upg_msg);
        return view();
    }
    
   
    public function help(){
       return view();
    }
 
    public function upgrade_act(){
        $type = request()->get('type','');
        if($type=='replace_one'){
            $file_old = request()->get('file_old','');
            $file_new = request()->get('file_new','');
            copy($file_old,$file_new);
            if(md5_file($file_old)==md5_file($file_new)){
                return jssuccess('替换成功');
            }else{
                return jserror('替换失败,请检查权限');
            }
        }elseif($type=='check_version'){
            //检测版本
            $data = $this->upg_data;
            $url = $this->upg_url;
            $ret = https_post($url,$data);
            $rr = json_decode($ret);
            if($rr){
                if( $rr->result==1 ){
                    //下载
                    $utoken = $rr->msg->utoken;
                    $xz =  $this->ZfUpgrade('ZFUpgradeDownSaveFileService',$utoken);
                    if($xz!='success'){
                        return jserror($xz);
                    }
                    // 解压
                    $jy = $this->ZfUpgrade('ZFUpgradeZip','jy');
                    if($jy!='success'){
                        return jserror($jy);
                    }
                    $back = $this->ZfUpgrade('ZFUpgradeZip','back');
                    if($back!='success'){
                        return jserror($back);
                    }
                    extraconfig(['version_temp'=>$rr->msg->version_new],'version');

                    return jssuccess('云文件已下载,请及时更新');



                    return jssuccess($rr->msg);
                }else{
                    return jserror($rr->msg);
                }
            }else{
                return jserror('通讯失败');
            }
        }elseif($type=='replace_all'){
            $ret = $this->ZfUpgrade('ZFUpgradeListFile');
            $list = $ret['update_file_arr'];
            foreach ($list as $k => $vo) {
                @copy($vo['path_old'],$vo['path_new']);
            }
            extraconfig(['version'=>config()['version']['version_temp']],'version');
            return jssuccess('替换成功');
        }elseif($type=='del_file'){

        }elseif($type=='bak_old'){
            $back = $this->ZfUpgrade('ZFUpgradeZip','back');
            if($back!='success'){
                return jserror($back);
            }else{
                return jssuccess('备份成功.备份路径 : '.$this->pulg_data_path.'/system/old_bak/');
            }
        }elseif($type=='yun_update'){
            //下载zip升级文件
            // $utoken = request()->get('utoken','');
            // $xz =  $this->ZfUpgrade('ZFUpgradeDownSaveFileService',$utoken);
            // if($xz!='success'){
            //     return jserror($xz);
            // }
            // // zip操作
            // // 解压
            // $jy = $this->ZfUpgrade('ZFUpgradeZip','jy');
            // if($jy!='success'){
            //     return jserror($jy);
            // }
            // $back = $this->ZfUpgrade('ZFUpgradeZip','back');
            // if($back!='success'){
            //     return jserror($back);
            // }
            // return jssuccess('云文件已下载,请及时更新');

        }else{
            //下载zip升级文件
            $this->ZfUpgrade('ZFUpgradeDownSaveFileService','');
            // zip操作
            // 解压
            $this->ZfUpgrade('ZFUpgradeZip','jy');
            $this->ZfUpgrade('ZFUpgradeZip','back');
            // 更新文件列表
            $ret = $this->ZfUpgrade('ZFUpgradeListFile');
            return view($this->tpl,compact('ret'));die;
        }
    }

    public function ZfUpgrade($func,$param=''){
        switch ($func) {
            case 'ZFUpgradeDownSaveFileService':
                $up_url = $param;
                return $this->ZFUpgradeDownSaveFileService($up_url, $this->pulg_data_path.'/system/zip', $filename = 'up.zip', $type = 0);        
                break;
            case 'ZFUpgradeZip':
                return $this->$func($param);
                break;
            default:
                return $this->$func();
                break;
        }
        
    }



    public function ZFUpgradeListFile(){
        $_list = [];
        $update_file_arr = [];

        $_temp_dir_list = $this->temp_dir_list;
        foreach ($_temp_dir_list as $key => $value) {
            // 原有的
            $list['old'][$key] = myScanDir("./".$value,'./'.$value,'./');
            foreach(arrToOne($list['old'][$key]) as $k=>$vo){
                if(strpos($vo,'{"name":"') !== false){ 
                    $_temp = json_decode($vo);
                    $_list['old'][$_temp->key]['name'] = $_temp;
                    $_list['old'][$_temp->key]['path'] = $_temp->path;
                    $_list['old'][$_temp->key]['name'] = $_temp->path_temp;
                    $_list['old'][$_temp->key]['md5'] = $_temp->md5;
                }
            }

            // 现在的最新的
            if(is_dir($this->pulg_data_path.'/system/new/'.$value)){
                $list['new'][$key] = myScanDir($this->pulg_data_path."/system/new/".$value,$this->pulg_data_path.'/system/new/'.$value,$this->pulg_data_path.'/system/new/','./');
                foreach(arrToOne($list['new'][$key]) as $k=>$vo){
                    if(strpos($vo,'{"name":"') !== false){ 
                        $_temp = json_decode($vo);
                        $_list['new'][$_temp->key]['name'] = $_temp;
                        $_list['new'][$_temp->key]['path'] = $_temp->path;
                        $_list['new'][$_temp->key]['name'] = $_temp->path_temp;
                        $_list['new'][$_temp->key]['md5'] = $_temp->md5;
                    }
                }
            }else{
                $_list['new'][$value] = [];
            }
        }
        // 重组数据
        foreach ($_list['new'] as $k => $vo) {
            if(count($vo)!=0){
                $ret[1][$k]['name'] = $vo['name'];
                $ret[1][$k]['path_old'] = $vo['path'];
                $ret[1][$k]['md5'] = $vo['md5'];
                if(isset($_list['old'][$k]['path'])){
                    $ret[1][$k]['path_new'] = $_list['old'][$k]['path'];
                    if($vo['md5']==$_list['old'][$k]['md5']){
                        $ret[1][$k]['is_xg'] = '未修改';
                    }else{
                        $ret[1][$k]['is_xg'] = "<span class='layui-bg-green'>已修改</span>";
                        $update_file_arr[] = ['name'=>$vo['name'],'path_old'=>$vo['path'],'md5'=>$vo['md5'],'path_new'=>$_list['old'][$k]['path'],'is_xg'=>'已修改'];
                    }
                }else{
                    $path_new = str_replace($this->pulg_data_path.'/system/new/', './', $vo['path']);
                    $ret[1][$k]['path_new'] = $path_new;
                    $ret[1][$k]['is_xg'] = "<span class='layui-bg-red'>新增文件</span>";
                    $update_file_arr[] = ['name'=>$vo['name'],'path_old'=>$vo['path'],'md5'=>$vo['md5'],'path_new'=>$path_new,'is_xg'=>'新增文件'];
                }
            }
        }
        foreach ($_list['old'] as $k => $vo) {
            if(!isset($_list['new'][$k])){
                $ret[2][$k]['name'] = $vo['name'];
                $ret[2][$k]['path_old'] = '';
                $ret[2][$k]['path_new'] = $vo['path'];
                $ret[2][$k]['md5'] = $vo['md5'];
                $ret[2][$k]['is_xg'] = '<span class="layui-bg-blue">差异文件(新系统中不含此文件,请酌情删除)</span>';
            }
        }
        if(!isset($ret['1'])){
            $ret['1'] = [];
        }
        if(!isset($ret['2'])){
            $ret['2'] = [];
        }
        if(isset($update_file_arr)){
            $ret['update_file_arr'] = $update_file_arr;
        }else{
            $ret['update_file_arr'] = [];
        }
        return $ret;
    }

    public function ZFUpgradeZip($type){
        if($type=='jy'){
            //删除目录
            if(is_dir($this->pulg_data_path.'/system/new')){
                $r = deldir($this->pulg_data_path.'/system/new');
                if(!$r){
                 die('删除目录失败,请检查权限$this->pulg_data_path.(/system/new)');   
                }
            }
            mkdir($this->pulg_data_path.'/system/new');
            $zip = new \ZipArchive();//新建一个对象
            if ($zip->open($this->pulg_data_path.'/system/zip/up.zip')=== TRUE){
                $r = $zip->extractTo($this->pulg_data_path.'/system/new/');//
                // 假设解压缩到在当前路径下images文件夹的子文件夹php
                $zip->close();//关闭处理的zip文件
            }
            if($r){
                return 'success';
            }else{
                return '解压失败';
            }

        }elseif($type=='back'){
            //路径是否存在
            if (!file_exists($this->pulg_data_path.'/system/old_bak') && !mkdir($this->pulg_data_path.'/system/old_bak', 0777, true)) {
                return false;
            }
            //压缩
            $file = $this->pulg_data_path.'/system/old_bak/'.date("YmdHis",time()).'_bak.zip';
            // 创建备份
            $zip = new \ZipArchive();                 
            if ($zip->open($file, \ZipArchive::CREATE)!==TRUE) {     
                exit("无法创建 <$filename>\n");     
            }     
            $files = $this->bak_path;
            foreach($files as $path){     
                $zip->addFile($path,str_replace("./","",str_replace("\\","/",$path)));    
            }   
            $zip->close(); 
            if(file_exists($file)){
                return 'success';
            }else{
                return '备份失败';
            }
        }
    }
    // 保存文件到服务器
    //链接   保存的路径 名称 类型
    public function ZFUpgradeDownSaveFileService($url, $save_dir = '', $filename = '', $type = 0) {
        if (trim($url) == '') {
            return false;
        }
        if (trim($save_dir) == '') {
            $save_dir = './';
        }
        if (0 !== strrpos($save_dir, '/')) {
            $save_dir.= '/';
        }
        //删除目录内容
        $ff = $save_dir.$filename;
        if(file_exists($ff)){
            unlink($ff);
        }
        #######
        //创建保存目录
        if (!file_exists($save_dir) && !mkdir($save_dir, 0777, true)) {
            return false;
        }
        //获取远程文件所采用的方法
        if ($type) {
            $ch = curl_init();
            $timeout = 5;
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
            $content = curl_exec($ch);
            curl_close($ch);
        } else {
            ob_start();
            readfile($url);
            $content = ob_get_contents();
            ob_end_clean();
        }
        $size = strlen($content);
        //文件大小
        $fp2 = @fopen($save_dir . $filename, 'a');
        fwrite($fp2, $content);
        fclose($fp2);
        unset($content, $url);
        if(is_file($save_dir . $filename)){
            return 'success';
        }else{
            return "下载失败";
        }
    }
}

function myScanDir($dir,$p_path='',$cj_ico)
{
    $file_arr = scandir($dir);
    $new_arr = [];
    $all_file = [];
    foreach($file_arr as $k => $item){
        $_path = $p_path;
        if($item!=".." && $item !="."){
            if(is_dir($dir."/".$item)){
                $_path = $dir."/".$item;
                $new_arr[$item] = myScanDir($dir."/".$item,$_path,$cj_ico);
            }else{
                $md5 = md5_file($_path.'/'.$item);
                $path_temp = isset(explode($cj_ico, $_path)[1])?explode($cj_ico, $_path)[1].'/':$cj_ico;
                $kk = $path_temp.pathinfo($item)['filename'];

                $new_arr[$kk] = array('name'=>$item,'path'=>$_path.'/'.$item ,'path_temp'=>$path_temp.$item  ,'md5'=>$md5);
                $new_arr[$kk]['key'] = $kk;
                $new_arr[$kk]['json'] = json_encode($new_arr[$kk]);
            } 
        }
    }
    return $new_arr;
}

function arrToOne($multi) {

  $arr = array();

  foreach ($multi as $key => $val) {

    if( is_array($val) ) {

      $arr = array_merge($arr, arrToOne($val));

    } else {

      $arr[] = $val;

    }

  }

  return $arr;

}

function deldir($dir) {
   //先删除目录下的文件：
   $dh=opendir($dir);
   while ($file=readdir($dh)) {
      if($file!="." && $file!="..") {
         $fullpath=$dir."/".$file;
         if(!is_dir($fullpath)) {
            unlink($fullpath);
         } else {
            deldir($fullpath);
         }
      }
   }
 
   closedir($dh);
   //删除当前文件夹：
   if(rmdir($dir)) {
      return true;
   } else {
      return false;
   }
}

function listdir($start_dir='.') {    
  $files = array();    
  if (is_dir($start_dir)) {    
   $fh = opendir($start_dir);    
   while (($file = readdir($fh)) !== false) {    
     if (strcmp($file, '.')==0 || strcmp($file, '..')==0) continue;    
     $filepath = $start_dir . '/' . $file;    
     if ( is_dir($filepath) )    
       $files = array_merge($files, listdir($filepath));    
     else   
       array_push($files, $filepath);    
   }    
   closedir($fh);    
  } else {    
   $files = false;    
  }    
 return $files;    
}
