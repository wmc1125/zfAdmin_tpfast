<?php
namespace addons\zf_upgrade\controller;

use think\Addons;
use think\App;

class Plugin extends Addons	// 需继承think\Addons类
{
    public function __construct(App $app = null)
    {
        parent::__construct($app);
    }

    public function _empty(){
        echo "没有此方法";die;
    }
    // 该插件的基础信息
    /**
     * 插件安装方法
     * @return bool
     */
    public function install()
    {
        $plugin_base = new \addons\AdFunction();
        //安装sql
        $arr[] = [ 'tb'=>'zf_test2' ,'sql'=>"CREATE TABLE `zf_test2` (
                  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                  `name` varchar(255) DEFAULT NULL,
                  PRIMARY KEY (`id`)
                ) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;"];
        $arr[] = [ 'tb'=>'zf_test1' ,'sql'=>"CREATE TABLE `zf_test1` (
                  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                  `name` varchar(255) DEFAULT NULL,
                  PRIMARY KEY (`id`)
                ) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;"];

        foreach ($arr as $k => $vo) {
            $plugin_base->sql_tb($vo['tb'],$vo['sql']);
        }
        return ['code'=>1,'msg'=>'ok'];
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {

      
      return ['code'=>1,'msg'=>'ok'];
    }

}