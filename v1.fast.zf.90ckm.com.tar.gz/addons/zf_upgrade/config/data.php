<?php
// 插件信息最后修改于 2020/06/12 11:12:13  
  
 return [
	'upg_url' => 'http://dev.v1.fast.zf.90ckm.com/addons/zf_soft_plugins.api/upg',
	'pulg_data_path' => './data/addons/zf_upgrade/data',
	'temp_dir_list' => 'application,extend',
];