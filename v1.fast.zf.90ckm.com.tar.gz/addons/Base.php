<?php
namespace addons;
use think\Controller;
use zf\ZfAuth;
use think\Db;

class Base extends Controller
{
	public function __construct (  )
    {
        parent::__construct();
        $this->z_role_list = get_admin_role(session("admin.gid"));
        // 默认给个权限
        $m = strtolower(request()->module());
        $c = strtolower(request()->controller());
        $a = strtolower(request()->action());
        $this->now_role = 'addons/'.$m.'.'.$c.'/'.$a;
        //支付不能判断是否登陆 ,当前是有支付回调

        //设置插件静态文件目录
        $plug_static = '/addons/'.$m.'/view/style/';
        $this->assign('plug_static',$plug_static);
        // echo "<br>";
        // echo $plug_static;

        //判断是否认证
        if(!isset(config()['zf_auth']['key']) || !isset(config()['zf_auth']['sc']) || !isset(config()['zf_auth']['email']) ||  config()['zf_auth']['key']=='' ||  config()['zf_auth']['sc']=='' ||  config()['zf_auth']['email']=='' ){
            $this->error('请先认证系统','admin/login/authentication_sys'); 
        }

        $auth_info['sc'] = config()['zf_auth']['sc'];
        $auth_info['key'] = config()['zf_auth']['key'];
        $auth_info['post_id'] = config()['version']['post_id'];


        //验证权限
        $this->zfauth = new ZfAuth();
        $this->zfauth->vfast_check($auth_info,'alert');
        $this->zfauth->plugin_check($auth_info,'alert');

        //检测系统是否激活 
        $plugin_name = $m;
        $plugin_info = Db::name('plugin')->where([['plugin_name','=',$plugin_name]])->find();
        if(!$plugin_info){
          $this->error('插件未安装');
        }
        //1 正常   2 未激活  9 停止使用
        if($plugin_info['status']==2){
            $controller_plugin =  '\addons\\'.$plugin_info['plugin_name'].'\\controller\\Plugin';
            $plug = new $controller_plugin();
            //激活方法
            $r = $plug->install();
            if($r['code']==1){
                // 激活成功,修改数据库
                Db::name('plugin')->where([['id','=',$plugin_info['id']]])->update(['status'=>1]);
                header("Location: /$this->now_role");
                exit();
            }else{
                return $r['msg'];
            }
        }
        
    }

    

    /**
     * @Notes:空方法
     * @Interface _empty
     * @author: 子枫
     * @Time: 2019/11/13   10:38 下午
     */
    public function _empty(){
        echo "没有此方法";
    }
   


}


