
  <?php
  // +----------------------------------------------------------------------
  // | 子枫后台管理系统(TpFast系列)[基于ThinkPHP5.1开发]
  // +----------------------------------------------------------------------
  // | Copyright (c)  http://v1.fast.zf.90ckm.com/
  // | 子枫后台管理系统提供免费使用,可使用此框架进行二次开发
  // +----------------------------------------------------------------------
  // | Author: 子枫 <287851074@qq.com>
  // +----------------------------------------------------------------------
  // | github:https://github.com/wmc1125/zfAdmin_tpfast
  // | 码云:  https://gitee.com/wmc1125/zfAdmin_tpfast
  // | Mc技术论坛: http://bbs.wangmingchang.com/forum.php?mod=forumdisplay&fid=77
  // +----------------------------------------------------------------------
  // 站点信息最后修改于 2020/06/14 12:09:45  
  
 return [
	'site_name' => '测试站点1',
	'site_url' => 'http://v1.zf.90ckm.com',
	'site_mail' => '287851074@qq.com',
	'site_hotline' => '88888888888',
	'site_fax' => '1111',
	'site_address' => '上海',
	'site_copyright' => '© 2019 www.90ckm.com ',
	'site_icp' => '沪ICP 888888888',
	'site_title' => '测试站点',
	'site_keywords' => '子枫,测试站点',
	'site_description' => '子枫 通用后台管理模板系统子枫 通用后台管理模板系统子枫 通用后台管理模板系统子枫 通用后台管理模板系统',
	'site_closed' => '0',
	'is_log' => '0',
	'is' => '0',
	'key_filter' => '121',
	'theme_name' => '',
	'pic_ext' => 'pjpeg,jpeg,jpg,gif,bmp,png',
	'file_ext' => 'txt,pdf,doc,xls,ppt,mp4,zip,jpg,pjpeg,jpeg,jpg,gif,bmp,png,log',
	'site_logo' => 'http://oss1.wangmingchang.com/0bd86e854d29ca97c3510e774d9cd4d4/public/admin/images/2020-02-24/56419phpMWjW1a1582538764200224.png',
	'site_icon' => 'http://oss1.wangmingchang.com/0bd86e854d29ca97c3510e774d9cd4d4/public/admin/images/2020-02-12/86212phpDyzonl1581496277200212.png',
	'site_qrcode' => 'http://oss1.wangmingchang.com/0bd86e854d29ca97c3510e774d9cd4d4/public/admin/images/2020-02-12/24172php7Z6xgm1581496724200212.jpeg',
];