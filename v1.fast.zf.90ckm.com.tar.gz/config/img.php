
  <?php
  // +----------------------------------------------------------------------
  // | 子枫后台管理系统(TpFast系列)[基于ThinkPHP5.1开发]
  // +----------------------------------------------------------------------
  // | Copyright (c)  http://v1.fast.zf.90ckm.com/
  // | 子枫后台管理系统提供免费使用,可使用此框架进行二次开发
  // +----------------------------------------------------------------------
  // | Author: 子枫 <287851074@qq.com>
  // +----------------------------------------------------------------------
  // | github:https://github.com/wmc1125/zfAdmin_tpfast
  // | 码云:  https://gitee.com/wmc1125/zfAdmin_tpfast
  // | Mc技术论坛: http://bbs.wangmingchang.com/forum.php?mod=forumdisplay&fid=77
  // +----------------------------------------------------------------------
  // 站点信息最后修改于 2020/05/16 20:08:58  
  
 return [
	'save_path' => '/public/upload/file',
	'water_path' => '',
	'water_clarity' => '33',
	'water_text' => 'demo',
	'water_text_size' => '20',
	'water_text_color' => '#1849bb',
	'water_font_path' => './public/upload/1.ttf',
	'water_position' => '6',
	'pic_save_type' => '0',
	'file_save_type' => '0',
	'is_water' => '0',
	'qn_ACCESSKEY' => '',
	'qn_SECRETKEY' => '',
	'qn_BUCKET' => '',
	'qn_DOMAIN' => '',
	'upyun_ACCESSKEY' => '',
	'upyun_SECRETKEY' => '',
	'upyun_BUCKET' => '',
	'upyun_DOMAIN' => '',
	'ali_ACCESSKEY' => '',
	'ali_SECRETKEY' => '',
	'ali_BUCKET' => '',
	'ali_DOMAIN' => '',
	'qn_type' => 'qny',
	'type' => 'qny',
];