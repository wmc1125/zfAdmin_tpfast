
  <?php
  // +----------------------------------------------------------------------
  // | 子枫后台管理系统(TpFast系列)[基于ThinkPHP5.1开发]
  // +----------------------------------------------------------------------
  // | Copyright (c)  http://v1.fast.zf.90ckm.com/
  // | 子枫后台管理系统提供免费使用,可使用此框架进行二次开发
  // +----------------------------------------------------------------------
  // | Author: 子枫 <287851074@qq.com>
  // +----------------------------------------------------------------------
  // | github:https://github.com/wmc1125/zfAdmin_tpfast
  // | 码云:  https://gitee.com/wmc1125/zfAdmin_tpfast
  // | Mc技术论坛: http://bbs.wangmingchang.com/forum.php?mod=forumdisplay&fid=77
  // +----------------------------------------------------------------------
  // 站点信息最后修改于 2020/06/11 11:16:55  
  
 return [
	'email' => '2046269887@qq.com',
	'key' => 'e3db021992ff1affb2974747581d6aa5263',
	'sc' => '4FOkzKicksnQoZWbolZxh2xixpvOY8Wk01ljWpnazZ\/KU2uUaXBknZVpZ2pmYFnKp5vQlYNvkmGIq7Com4ieVMadnYVgWaPX0FZuVGdkWZFVl9CRyqGEb4hpZ2xsmJprnWloo6WoYcjQoVZeVp+c3lVshZWUmcRlmGhwcWjMymPGl5fFZnBqmZhoa2dsZZublJOYYpdohLI=',
];